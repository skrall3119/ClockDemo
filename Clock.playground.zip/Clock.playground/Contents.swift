import Cocoa

func getCurrentTime() {
    let formatter = DateFormatter()
    formatter.dateFormat = "hh:mm:ss"
    let str = formatter.string(from: Date())
    print(str)
}

let timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { (Timer) in
    getCurrentTime()
})

